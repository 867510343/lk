import pymysql
import re

# 创建数据库对象
db = pymysql.connect(host = 'localhost',user = "root",password = "123456",db = 'dict',charset = "utf8",port = 3306)
# 创建游标对象
cursor = db.cursor()
# 打开文件
file = open('dict')
pattern = r"(?P<name>[a-z|A-Z]+[\.\,\-\']?(\?{2})?\(?[a-zA-Z]*\)?[\.\-]?[a-z]*\-?[a-z]*)\s+(?P<explains>[^0-9\r\n]*)"
while True:
    # 按行读取文件内容
    data = file.readline()
    # 如果没有数据,跳出循环
    if not data:
        break
    data = re.match(pattern,data).groupdict()
    name = data['name']
    explains = data['explains']
    # print(name)
    # print(explains)

    try:
        # 执行SQL语句
        SQL = 'insert into word(name,explains) values(%s,%s)'
        cursor.execute(SQL,[name,explains])
        db.commit()
    except Exception as e:
        db.rollback()
        print("失败",e)

file.close()
cursor.close()
db.close()










