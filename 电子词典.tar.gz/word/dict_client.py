from socket import *
import sys
import os
import pymysql
import getpass

def do_history(sockfd,username):
    # 发送请求消息
    msg = 'H {}'.format(username)
    sockfd.send(msg.encode())
    # 接收请求数据
    data = sockfd.recv(128).decode()
    if data == 'ok':
        while True:
            data = sockfd.recv(1024).decode()
            if data == '##':
                break
            print(data)
    else:
        print('没有历史记录')


# 查询操作
def do_query(sockfd,username):
    while True:
        try:
            word = input("请输入要查询地单词(输入##退出):")
        except KeyboardInterrupt:
            sys.exit('退出成功')
        if word == '##':
            break
        msg = 'Q {} {}'.format(username,word)
        sockfd.send(msg.encode())
        # 接收服务端发来的消息
        data = sockfd.recv(128).decode()
        # 如果消息为ok
        if data == 'ok':
            # 接收查询结果
            data = sockfd.recv(2048).decode()
            print(data)
        # 接收fall,打印未搜到单词
        else:
            print('未搜索到单词')

# 一级界面
def login(sockfd,username):
    while True:
        print('''
            -----------查询界面---------
            |           1.查询          |
            |           2.历史记录      |
            |           q.注销          |
            '----------------------------''')
        try:
            cmd = input("请输入命令:")
        except Exception as e:
            print("命令错误")
            continue 
        except KeyboardInterrupt:
            # 返回上一级界面
            return

        if cmd == '1':
            do_query(sockfd,username)
        elif cmd == '2':
            do_history(sockfd,username)
        elif cmd == 'q':
            return
        else:
            print('请输入正确选项')
            #清除标准输入
            sys.stdin.flush() 
            continue 

# 登录,输入用户名密码
def do_login(sockfd):
    try:
        username = input('username:')
    except KeyboardInterrupt:
        sys.exit('谢谢使用')
    try:
        password = input('password:')
    except KeyboardInterrupt:
        sys.exit('谢谢使用')
    
    # 将username和password发送给服务端,到数据库进行查找
    msg = 'L {} {}'.format(username,password)
    sockfd.send(msg.encode())

    # 接收服务端的消息
    data = sockfd.recv(128).decode()
    # 如果收到ok
    if data == 'ok':
        # 返回用户名
        return username
    else:
        return

# 注册
def do_register(sockfd):
    while True:
        try:
            username = input('请输入姓名:')
        except KeyboardInterrupt:
            sys.exit("程序退出")
        # 隐藏密码输入
        # password = getpass.getpass()
        try:
            password = input('请输入密码:')
        except KeyboardInterrupt:
            sys.exit("程序退出")
        try:
            password1 = input('请再次输入密码:')
        except KeyboardInterrupt:
            sys.exit("程序退出")
        if (' ' in username) or (' ' in password):
            print("用户名和密码不能有空格")
            continue
        if password != password1:
            print('两次密码不一致')
            continue

        msg = 'R {} {}'.format(username,password)
        sockfd.send(msg.encode())

        data = sockfd.recv(128).decode()
        if data == 'ok':
            return 0
        elif data == 'EXISTS':
            return 1
        else:
            return 2

def main():
    # 在终端输入ip地址和端口号port,如果输入的长度小于3
    if len(sys.argv) < 3:
        print('argv is error')
        return
    # 获取ip和端口号
    Host = sys.argv[1]
    Port = int(sys.argv[2])
    Addr = (Host,Port)
    # 创建套接字
    sockfd = socket()
    try:
        sockfd.connect(Addr)
    except Exception as e:
        print(e)
        return
    
    while True:
        print('''
    -------欢迎进入电子词典------
    |           1.登录          |
    |           2.注册          |
    |           q.退出          |
    '----------------------------''')
        try:
            cmd = input('请输入功能序号:')
        except Exception as e:
            print('命令错误')
            continue
        except KeyboardInterrupt:
            sys.exit("程序退出")

        if cmd == '1':
            username = do_login(sockfd)
            # 如果有返回的用户名
            if username:
                print('登录成功')
                # 进入一级界面
                login(sockfd,username)
            else:
                print('用户名或密码错误')
        elif cmd == '2':
            r = do_register(sockfd)
            if r == 0:
                print('注册成功')
            elif r == 1:
                print('用户已存在')
            else:
                print('注册失败')
        elif cmd == 'q':
            sockfd.send(b'Q')
            sys.exit('谢谢使用')
        else:
            print('请输入正确命令')
            # 清除标准输入
            sys.stdin.flush()
            continue
        

if __name__ == '__main__':
    main()




