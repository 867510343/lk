from socket import *
import pymysql
import os
import sys
from time import sleep



HOST = '0.0.0.0'
PORT = 7878
ADDR = (HOST,PORT)



def main():
    db = pymysql.connect(host="localhost",
    user="root",
    password="123456",
    db = 'dict',
    charset="utf8",
    port=3306)

    sockfd = socket()
    sockfd.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
    sockfd.bind(ADDR)
    sockfd.listen(5)

    while True:
        try:
            connfd,addr = sockfd.accept()
            print("连接:",ADDR)
        except KeyboardInterrupt:
            sockfd.close()
            sys.exit('服务器退出')
        except Exception as e:
            print(e)
            continue

        pid = os.fork()
        if pid == 0:
            sockfd.close()
            do_child(connfd,db)
        else:
            connfd.close()
            continue
# 子进程
def do_child(connfd,db):
    while True:
        data = connfd.recv(128).decode()
        print(connfd.getpeername(),':',data)
        if (not data) or data[0] == 'q':
            connfd.close()
            sys.exit(0)
        elif data[0] == 'R':
            do_register(connfd,db,data)
        elif data[0] == 'L':
            do_login(connfd,db,data)
        elif data[0] == 'Q':
            do_query(connfd,db,data)
        elif data[0] == 'H':
            do_hist(connfd,db,data)

# 登录
def do_login(connfd,db,data):
    l = data.split(' ')
    username = l[1]
    password = l[2]

    cursor = db.cursor()
    SQL = "select * from user where name = '%s' and passwd = '%s'"%(username,password)
    cursor.execute(SQL)
    r = cursor.fetchone()

    if r == None:
        connfd.send(b'fall')
    else:
        connfd.send(b'ok')
        print('%s登陆成功'%username)
    
# 注册
def do_register(connfd,db,data):
    
    l = data.split(' ')
    username = l[1]
    password = l[2]
    # 创建游标对象
    cursor = db.cursor()

    SQL = "select * from user where name = '%s'"%username
    cursor.execute(SQL)
    r = cursor.fetchone()

    if r != None:
        connfd.send(b'EXISTS')
        return

    SQL = 'insert into user(name,passwd) values(%s,%s)'
    try:
        cursor.execute(SQL,[username,password])
        db.commit()
        connfd.send(b'ok')
    except:
        db.rollback()
        connfd.send(b'fall')
    else:
        print("%s注册成功"%username)

# 查询单词
def do_query(connfd,db,data):
    # 将接收的数据用空格切割成列表
    l = data.split(' ')
    username = l[1]
    word = l[2]
    cursor = db.cursor()

    # 将查询的记录存入数据库
    def do_hist():
            # 查看数据库该单词是否存在
            SQL1 = 'select name,word from hist where name = %s and word = %s'
            cursor.execute(SQL1,[username,word])
            result = cursor.fetchone()
            db.commit()
            # 如果不存在
            if result == None:
                # 插入历史记录
                SQL2 = 'insert into hist(name,word) values(%s,%s)'
                try:
                    cursor.execute(SQL2,[username,word])
                    db.commit()
                except:
                    db.rollback()
            else:
                print('该单词已存在历史记录')

    SQL = 'select name,explains from word where name = %s'
    try:
        cursor.execute(SQL,word)
        db.commit()
    except:
        db.rollback()

    # 返回一个(word,explains)元组
    a = cursor.fetchone()
    # 如果返回的不是None
    if a != None:
        # 建一个空列表
        result = []
        # 遍历元组
        for i in a:
            # 将结果添加到列表中
            result.append(i)
        # 将列表的元素用多个空格分开,形成字符串
        a = '     '.join(result)
        # 向客户端发送ok
        connfd.send(b'ok')
        # 睡眠0.1s防止粘包
        sleep(0.1)
        # 将查询结果发送给客户端
        connfd.send(a.encode())
        do_hist()

    # 如果查询的结果为None
    else:
        # 给客户端发送fall
        connfd.send(b'fall')
    
# 查看历史记录
def do_hist(connfd,db,data):
    # 将接收的数据用空格切割成列表
    l = data.split(' ')
    username = l[1]
    
    cursor = db.cursor()
    SQL = 'select * from hist where name = %s'
    try:
        cursor.execute(SQL,username)
        db.commit()
    except:
        db.rollback()

    result = cursor.fetchall()
    print(result)
    if not result:
        connfd.send(b'fall')
        return
    else:
        connfd.send(b'ok')

    for i in result:
        sleep(0.1)
        msg = "%s %s"%(i[1],i[2])
        connfd.send(msg.encode())
    sleep(0.1)
    connfd.send(b'##')


if __name__ == '__main__':
    main()

